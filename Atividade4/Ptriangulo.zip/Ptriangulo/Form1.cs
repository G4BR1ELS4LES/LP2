﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ptriangulo
{
    public partial class Form1 : Form
    {
        double ladoa, ladob, ladoc;

        private void txtba_Validating(object sender, CancelEventArgs e)
        {
            if (!double.TryParse(txtba.Text, out ladoa))
            {
                MessageBox.Show("Somente Numeros!!!");
                txtba.Clear();
                txtba.Focus();
            }
        }

        private void btnlimpar_Click(object sender, EventArgs e)
        {
            txtba.Clear();
            txtbb.Clear();
            txtbc.Clear();
        }

        private void btnsair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnverificar_Click(object sender, EventArgs e)
        {
            if (ladoa < (ladob + ladoc) && (ladoa > (Math.Abs(ladob - ladoc))) &&
                ladob < (ladoa + ladoc) && (ladob > (Math.Abs(ladoa - ladoc))) &&
                ladoc < (ladoa + ladob) && (ladoc > (Math.Abs(ladoa - ladob))))
            {
                if (ladoa == ladob && ladoa == ladoc)
                    MessageBox.Show("Triangulo Equilátero!");
                else
                    if (ladoa == ladob || ladob == ladoc || ladoa == ladoc)
                    MessageBox.Show("Triangulo Isósceles!");
                else
                    MessageBox.Show("Triangulo Escaleno!");
            }
            else
                MessageBox.Show("Não é um triangulo...");
        }

        private void txtbb_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtbb_Validating(object sender, CancelEventArgs e)
        {
            if (!double.TryParse(txtbb.Text, out ladob))
            {
                MessageBox.Show("Somente Numeros!!!");
                txtbb.Clear();
                txtbb.Focus();
            }
        }

        private void txtbc_Validating(object sender, CancelEventArgs e)
        {
            if (!double.TryParse(txtbc.Text, out ladoc))
            {
                MessageBox.Show("Somente Numeros!!!");
                txtbc.Clear();
                txtbc.Focus();
            }
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
