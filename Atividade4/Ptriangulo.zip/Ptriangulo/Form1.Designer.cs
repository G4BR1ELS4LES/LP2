﻿namespace Ptriangulo
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbla = new System.Windows.Forms.Label();
            this.lblb = new System.Windows.Forms.Label();
            this.lblc = new System.Windows.Forms.Label();
            this.txtba = new System.Windows.Forms.TextBox();
            this.txtbb = new System.Windows.Forms.TextBox();
            this.txtbc = new System.Windows.Forms.TextBox();
            this.btnverificar = new System.Windows.Forms.Button();
            this.btnlimpar = new System.Windows.Forms.Button();
            this.btnsair = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lbla
            // 
            this.lbla.AutoSize = true;
            this.lbla.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbla.Location = new System.Drawing.Point(110, 91);
            this.lbla.Name = "lbla";
            this.lbla.Size = new System.Drawing.Size(60, 20);
            this.lbla.TabIndex = 0;
            this.lbla.Text = "Lado A";
            // 
            // lblb
            // 
            this.lblb.AutoSize = true;
            this.lblb.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblb.Location = new System.Drawing.Point(110, 137);
            this.lblb.Name = "lblb";
            this.lblb.Size = new System.Drawing.Size(60, 20);
            this.lblb.TabIndex = 1;
            this.lblb.Text = "Lado B";
            // 
            // lblc
            // 
            this.lblc.AutoSize = true;
            this.lblc.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblc.Location = new System.Drawing.Point(110, 183);
            this.lblc.Name = "lblc";
            this.lblc.Size = new System.Drawing.Size(60, 20);
            this.lblc.TabIndex = 2;
            this.lblc.Text = "Lado C";
            // 
            // txtba
            // 
            this.txtba.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtba.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.txtba.Location = new System.Drawing.Point(210, 88);
            this.txtba.Name = "txtba";
            this.txtba.Size = new System.Drawing.Size(182, 26);
            this.txtba.TabIndex = 3;
            this.txtba.Validating += new System.ComponentModel.CancelEventHandler(this.txtba_Validating);
            // 
            // txtbb
            // 
            this.txtbb.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbb.ForeColor = System.Drawing.Color.Green;
            this.txtbb.Location = new System.Drawing.Point(210, 134);
            this.txtbb.Name = "txtbb";
            this.txtbb.Size = new System.Drawing.Size(182, 26);
            this.txtbb.TabIndex = 4;
            this.txtbb.TextChanged += new System.EventHandler(this.txtbb_TextChanged);
            this.txtbb.Validating += new System.ComponentModel.CancelEventHandler(this.txtbb_Validating);
            // 
            // txtbc
            // 
            this.txtbc.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbc.ForeColor = System.Drawing.Color.Maroon;
            this.txtbc.Location = new System.Drawing.Point(210, 180);
            this.txtbc.Name = "txtbc";
            this.txtbc.Size = new System.Drawing.Size(182, 26);
            this.txtbc.TabIndex = 5;
            this.txtbc.Validating += new System.ComponentModel.CancelEventHandler(this.txtbc_Validating);
            // 
            // btnverificar
            // 
            this.btnverificar.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnverificar.Location = new System.Drawing.Point(255, 245);
            this.btnverificar.Name = "btnverificar";
            this.btnverificar.Size = new System.Drawing.Size(137, 39);
            this.btnverificar.TabIndex = 6;
            this.btnverificar.Text = "Verificar";
            this.btnverificar.UseVisualStyleBackColor = true;
            this.btnverificar.Click += new System.EventHandler(this.btnverificar_Click);
            // 
            // btnlimpar
            // 
            this.btnlimpar.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnlimpar.Location = new System.Drawing.Point(114, 245);
            this.btnlimpar.Name = "btnlimpar";
            this.btnlimpar.Size = new System.Drawing.Size(79, 39);
            this.btnlimpar.TabIndex = 7;
            this.btnlimpar.Text = "Limpar";
            this.btnlimpar.UseVisualStyleBackColor = true;
            this.btnlimpar.Click += new System.EventHandler(this.btnlimpar_Click);
            // 
            // btnsair
            // 
            this.btnsair.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnsair.Location = new System.Drawing.Point(408, 339);
            this.btnsair.Name = "btnsair";
            this.btnsair.Size = new System.Drawing.Size(91, 30);
            this.btnsair.TabIndex = 8;
            this.btnsair.Text = "Sair";
            this.btnsair.UseVisualStyleBackColor = true;
            this.btnsair.Click += new System.EventHandler(this.btnsair_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(511, 381);
            this.Controls.Add(this.btnsair);
            this.Controls.Add(this.btnlimpar);
            this.Controls.Add(this.btnverificar);
            this.Controls.Add(this.txtbc);
            this.Controls.Add(this.txtbb);
            this.Controls.Add(this.txtba);
            this.Controls.Add(this.lblc);
            this.Controls.Add(this.lblb);
            this.Controls.Add(this.lbla);
            this.Name = "Form1";
            this.Text = "Ptriangulo";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbla;
        private System.Windows.Forms.Label lblb;
        private System.Windows.Forms.Label lblc;
        private System.Windows.Forms.TextBox txtba;
        private System.Windows.Forms.TextBox txtbb;
        private System.Windows.Forms.TextBox txtbc;
        private System.Windows.Forms.Button btnverificar;
        private System.Windows.Forms.Button btnlimpar;
        private System.Windows.Forms.Button btnsair;
    }
}

