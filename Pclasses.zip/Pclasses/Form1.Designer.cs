﻿namespace Pclasses
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnmensalista = new System.Windows.Forms.Button();
            this.btnhorista = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnmensalista
            // 
            this.btnmensalista.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnmensalista.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnmensalista.Location = new System.Drawing.Point(189, 148);
            this.btnmensalista.Name = "btnmensalista";
            this.btnmensalista.Size = new System.Drawing.Size(114, 70);
            this.btnmensalista.TabIndex = 0;
            this.btnmensalista.Text = "Mensalista";
            this.btnmensalista.UseVisualStyleBackColor = false;
            this.btnmensalista.Click += new System.EventHandler(this.btnmensalista_Click);
            // 
            // btnhorista
            // 
            this.btnhorista.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnhorista.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnhorista.Location = new System.Drawing.Point(471, 148);
            this.btnhorista.Name = "btnhorista";
            this.btnhorista.Size = new System.Drawing.Size(114, 70);
            this.btnhorista.TabIndex = 1;
            this.btnhorista.Text = "Horista";
            this.btnhorista.UseVisualStyleBackColor = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(781, 397);
            this.Controls.Add(this.btnhorista);
            this.Controls.Add(this.btnmensalista);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnmensalista;
        private System.Windows.Forms.Button btnhorista;
    }
}

