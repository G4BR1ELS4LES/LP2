﻿namespace Pclasses
{
    partial class frmmensalista
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblmatricula = new System.Windows.Forms.Label();
            this.lblnome = new System.Windows.Forms.Label();
            this.lblsalariomensal = new System.Windows.Forms.Label();
            this.lbldataentrada = new System.Windows.Forms.Label();
            this.txtmatricula = new System.Windows.Forms.TextBox();
            this.txtnome = new System.Windows.Forms.TextBox();
            this.txtsalario = new System.Windows.Forms.TextBox();
            this.txtdataentrada = new System.Windows.Forms.TextBox();
            this.btninsmensalista = new System.Windows.Forms.Button();
            this.btninsmensalista2 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblmatricula
            // 
            this.lblmatricula.AutoSize = true;
            this.lblmatricula.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblmatricula.Location = new System.Drawing.Point(97, 64);
            this.lblmatricula.Name = "lblmatricula";
            this.lblmatricula.Size = new System.Drawing.Size(73, 20);
            this.lblmatricula.TabIndex = 0;
            this.lblmatricula.Text = "Matrícula";
            this.lblmatricula.Click += new System.EventHandler(this.lblmatricula_Click);
            // 
            // lblnome
            // 
            this.lblnome.AutoSize = true;
            this.lblnome.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblnome.Location = new System.Drawing.Point(97, 102);
            this.lblnome.Name = "lblnome";
            this.lblnome.Size = new System.Drawing.Size(51, 20);
            this.lblnome.TabIndex = 1;
            this.lblnome.Text = "Nome";
            this.lblnome.Click += new System.EventHandler(this.lblnome_Click);
            // 
            // lblsalariomensal
            // 
            this.lblsalariomensal.AutoSize = true;
            this.lblsalariomensal.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblsalariomensal.Location = new System.Drawing.Point(97, 139);
            this.lblsalariomensal.Name = "lblsalariomensal";
            this.lblsalariomensal.Size = new System.Drawing.Size(113, 20);
            this.lblsalariomensal.TabIndex = 2;
            this.lblsalariomensal.Text = "Salário Mensal";
            this.lblsalariomensal.Click += new System.EventHandler(this.lblsalariomensal_Click);
            // 
            // lbldataentrada
            // 
            this.lbldataentrada.AutoSize = true;
            this.lbldataentrada.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbldataentrada.Location = new System.Drawing.Point(97, 179);
            this.lbldataentrada.Name = "lbldataentrada";
            this.lbldataentrada.Size = new System.Drawing.Size(195, 20);
            this.lbldataentrada.TabIndex = 3;
            this.lbldataentrada.Text = "Data Entrada na Empresa";
            this.lbldataentrada.Click += new System.EventHandler(this.lbldataentrada_Click);
            // 
            // txtmatricula
            // 
            this.txtmatricula.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtmatricula.Location = new System.Drawing.Point(206, 61);
            this.txtmatricula.Name = "txtmatricula";
            this.txtmatricula.Size = new System.Drawing.Size(481, 26);
            this.txtmatricula.TabIndex = 4;
            // 
            // txtnome
            // 
            this.txtnome.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtnome.Location = new System.Drawing.Point(184, 99);
            this.txtnome.Name = "txtnome";
            this.txtnome.Size = new System.Drawing.Size(503, 26);
            this.txtnome.TabIndex = 5;
            // 
            // txtsalario
            // 
            this.txtsalario.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtsalario.Location = new System.Drawing.Point(246, 136);
            this.txtsalario.Name = "txtsalario";
            this.txtsalario.Size = new System.Drawing.Size(441, 26);
            this.txtsalario.TabIndex = 6;
            // 
            // txtdataentrada
            // 
            this.txtdataentrada.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtdataentrada.Location = new System.Drawing.Point(328, 176);
            this.txtdataentrada.Name = "txtdataentrada";
            this.txtdataentrada.Size = new System.Drawing.Size(359, 26);
            this.txtdataentrada.TabIndex = 7;
            // 
            // btninsmensalista
            // 
            this.btninsmensalista.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btninsmensalista.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btninsmensalista.Location = new System.Drawing.Point(231, 264);
            this.btninsmensalista.Name = "btninsmensalista";
            this.btninsmensalista.Size = new System.Drawing.Size(207, 81);
            this.btninsmensalista.TabIndex = 8;
            this.btninsmensalista.Text = "Instanciar Mensalista";
            this.btninsmensalista.UseVisualStyleBackColor = false;
            this.btninsmensalista.Click += new System.EventHandler(this.btninsmensalista_Click);
            // 
            // btninsmensalista2
            // 
            this.btninsmensalista2.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btninsmensalista2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btninsmensalista2.Location = new System.Drawing.Point(480, 264);
            this.btninsmensalista2.Name = "btninsmensalista2";
            this.btninsmensalista2.Size = new System.Drawing.Size(207, 81);
            this.btninsmensalista2.TabIndex = 9;
            this.btninsmensalista2.Text = "Instanciar Mensalista passando parâmetros";
            this.btninsmensalista2.UseVisualStyleBackColor = false;
            this.btninsmensalista2.Click += new System.EventHandler(this.btninsmensalista2_Click);
            // 
            // frmmensalista
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 430);
            this.Controls.Add(this.btninsmensalista2);
            this.Controls.Add(this.btninsmensalista);
            this.Controls.Add(this.txtdataentrada);
            this.Controls.Add(this.txtsalario);
            this.Controls.Add(this.txtnome);
            this.Controls.Add(this.txtmatricula);
            this.Controls.Add(this.lbldataentrada);
            this.Controls.Add(this.lblsalariomensal);
            this.Controls.Add(this.lblnome);
            this.Controls.Add(this.lblmatricula);
            this.Name = "frmmensalista";
            this.Text = "frmmensalista";
            this.Load += new System.EventHandler(this.frmmensalista_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblmatricula;
        private System.Windows.Forms.Label lblnome;
        private System.Windows.Forms.Label lblsalariomensal;
        private System.Windows.Forms.Label lbldataentrada;
        private System.Windows.Forms.TextBox txtmatricula;
        private System.Windows.Forms.TextBox txtnome;
        private System.Windows.Forms.TextBox txtsalario;
        private System.Windows.Forms.TextBox txtdataentrada;
        private System.Windows.Forms.Button btninsmensalista;
        private System.Windows.Forms.Button btninsmensalista2;
    }
}