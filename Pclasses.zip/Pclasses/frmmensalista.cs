﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pclasses
{
    public partial class frmmensalista : Form
    {
        public frmmensalista()
        {
            InitializeComponent();
        }

        private void frmmensalista_Load(object sender, EventArgs e)
        {

        }

        private void lblnome_Click(object sender, EventArgs e)
        {

        }

        private void lblsalariomensal_Click(object sender, EventArgs e)
        {

        }

        private void lblmatricula_Click(object sender, EventArgs e)
        {

        }

        private void lbldataentrada_Click(object sender, EventArgs e)
        {

        }

        private void btninsmensalista_Click(object sender, EventArgs e)
        {
            Mensalista objMensalista = new Mensalista();

            objMensalista.NomeEmpregado = txtnome.Text;
            objMensalista.Matricula = Convert.ToInt32(txtmatricula.Text);
            objMensalista.DataEntradaEmpresa = Convert.ToDateTime(txtdataentrada.Text);
            objMensalista.SalarioMensal = Convert.ToDouble(txtsalario.Text);

            MessageBox.Show("Nome = " + objMensalista.NomeEmpregado + "\n" +
                            "Matrícula = " + objMensalista.Matricula + "\n" +
                            "Tempo de Trabalho: " + objMensalista.TempoTrabalho() + "\n" +
                            "Salário Final = " + objMensalista.SalarioBruto().ToString("N2"));
        }

        private void btninsmensalista2_Click(object sender, EventArgs e)
        {
            Mensalista ObjMensalista = new Mensalista(
                Convert.ToInt32(txtmatricula.Text),
                txtnome.Text,
                Convert.ToDateTime(txtdataentrada.Text),
                Convert.ToDouble(txtsalario.Text));

            MessageBox.Show("Nome = " + ObjMensalista.NomeEmpregado + "\n" +
                            "Matrícula = " + ObjMensalista.Matricula + "\n" +
                            "Tempo de Trabalho: " + ObjMensalista.TempoTrabalho() + "\n" +
                            "Salário Final = " + ObjMensalista.SalarioBruto().ToString("N2"));
        }
    }
}
