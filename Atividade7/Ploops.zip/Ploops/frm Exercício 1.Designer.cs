﻿namespace Ploops
{
    partial class frm_Exercício_1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.rchtxtfrase = new System.Windows.Forms.RichTextBox();
            this.btnspbranco = new System.Windows.Forms.Button();
            this.btnletrar = new System.Windows.Forms.Button();
            this.btnparletras = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // rchtxtfrase
            // 
            this.rchtxtfrase.Location = new System.Drawing.Point(225, 61);
            this.rchtxtfrase.MaxLength = 100;
            this.rchtxtfrase.Name = "rchtxtfrase";
            this.rchtxtfrase.Size = new System.Drawing.Size(322, 136);
            this.rchtxtfrase.TabIndex = 0;
            this.rchtxtfrase.Text = "";
            // 
            // btnspbranco
            // 
            this.btnspbranco.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnspbranco.Location = new System.Drawing.Point(108, 263);
            this.btnspbranco.Name = "btnspbranco";
            this.btnspbranco.Size = new System.Drawing.Size(156, 68);
            this.btnspbranco.TabIndex = 1;
            this.btnspbranco.Text = "Espaços em branco";
            this.btnspbranco.UseVisualStyleBackColor = true;
            this.btnspbranco.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnletrar
            // 
            this.btnletrar.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnletrar.Location = new System.Drawing.Point(302, 263);
            this.btnletrar.Name = "btnletrar";
            this.btnletrar.Size = new System.Drawing.Size(156, 68);
            this.btnletrar.TabIndex = 2;
            this.btnletrar.Text = "Quantidade de letra R";
            this.btnletrar.UseVisualStyleBackColor = true;
            this.btnletrar.Click += new System.EventHandler(this.button2_Click);
            // 
            // btnparletras
            // 
            this.btnparletras.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnparletras.Location = new System.Drawing.Point(494, 263);
            this.btnparletras.Name = "btnparletras";
            this.btnparletras.Size = new System.Drawing.Size(156, 68);
            this.btnparletras.TabIndex = 3;
            this.btnparletras.Text = "Quantidade de par de letras";
            this.btnparletras.UseVisualStyleBackColor = true;
            this.btnparletras.Click += new System.EventHandler(this.button3_Click);
            // 
            // frm_Exercício_1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnparletras);
            this.Controls.Add(this.btnletrar);
            this.Controls.Add(this.btnspbranco);
            this.Controls.Add(this.rchtxtfrase);
            this.Name = "frm_Exercício_1";
            this.Text = "frm_Exercício_1";
            this.Load += new System.EventHandler(this.frm_Exercício_1_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.RichTextBox rchtxtfrase;
        private System.Windows.Forms.Button btnspbranco;
        private System.Windows.Forms.Button btnletrar;
        private System.Windows.Forms.Button btnparletras;
    }
}