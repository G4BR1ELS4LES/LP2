﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ploops
{
    public partial class frm_Exercício_1 : Form
    {
        public frm_Exercício_1()
        {
            InitializeComponent();
        }

        private void frm_Exercício_1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            int vaz = 0;
            for(int i = 0;i<rchtxtfrase.Text.Length;i++)
            {
                if (rchtxtfrase.Text[i] == ' ')
                    vaz = vaz + 1;
            }

            MessageBox.Show("Quantidade de espaços vazio é "+vaz);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            int letr = 0;
            int i = 0;
            do
            {
                if (rchtxtfrase.Text[i] == 'R' || rchtxtfrase.Text[i] == 'r')
                    letr = letr + 1;

                i++;
            }
            while (i < rchtxtfrase.Text.Length);

            MessageBox.Show("Quantidade de caracteres R é: "+letr);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            int dlet = 0;
            int i = 0;
            int tl = 0;

                while (i < 100)
                {

                tl = i + 1;

                if (dlet == 99)
                    break;

                if (rchtxtfrase.Text[i] == rchtxtfrase.Text[tl])
                    dlet = dlet + 1;

                i++;
                }

            MessageBox.Show("Quantidade de letras repetidas em sequencia é: "+dlet);
        }
    }
}
