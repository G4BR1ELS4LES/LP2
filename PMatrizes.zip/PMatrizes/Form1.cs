﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.NetworkInformation;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PMatrizes
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnExercicio1_Click(object sender, EventArgs e)
        {
            int[] vetor = new int[20];
            string auxiliar = "";
            string saida = "";

            for (var i = 0; i < 20; i++)
            {
                auxiliar = Interaction.InputBox("Digite o número", "Entrada de dados");

                if (!int.TryParse(auxiliar, out vetor[i]))
                {
                    MessageBox.Show("Número inválido");
                    i--;
                }
                else
                {
                    saida += vetor[i] + "\n"+saida;
                }
            }
            MessageBox.Show(saida);

            Array.Reverse(vetor);
            auxiliar = "";
            foreach (var i in vetor)
            {
                auxiliar += i +"\n";
            }

            MessageBox.Show(auxiliar);
        }

        private void btnExercicio2_Click(object sender, EventArgs e)
        {
            ArrayList lista = new ArrayList() {"Ana", "André", "Débora", "Fátima", "João", "Janete", "Otávio", "Marcelo", "Pedro", "Thais"};
            lista.Remove("Otávio");

            string aux = "";

            foreach (string s in lista)
            {
                aux += s + "\n";
            }
            MessageBox.Show(aux);
        }

        private void btnExercicio3_Click(object sender, EventArgs e)
        {
            Double[,] notas = new double[20, 3];
            Double[] media = new double[20];
            string[] almed = new string[20];
            string auxiliar2 = "";
            string saida2 = "";

            for (int i = 0; i < 20; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    auxiliar2 = Interaction.InputBox("Digite a nota da prova " + (j + 1) + ", do aluno numero " + (i + 1), "Entrada de dados");

                    if (!double.TryParse(auxiliar2, out notas[i, j]) || notas[i, j] < 0 || notas[i, j] > 10)
                    {
                        MessageBox.Show("Número inválido");
                        j--;
                    }
                    else
                    {
                        saida2 += notas[i, j] + "\n";
                    }
                    media[i] = (notas[i, 0] + notas[i, 1] + notas[i, 2]) / 3;
                }

            }

            
        }
    }
}
