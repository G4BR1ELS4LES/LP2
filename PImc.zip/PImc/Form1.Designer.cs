﻿namespace PImc
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblpeso = new System.Windows.Forms.Label();
            this.lblaltura = new System.Windows.Forms.Label();
            this.lblimc = new System.Windows.Forms.Label();
            this.btncalcular = new System.Windows.Forms.Button();
            this.btnlimpar = new System.Windows.Forms.Button();
            this.btnsair = new System.Windows.Forms.Button();
            this.mskbxpeso = new System.Windows.Forms.MaskedTextBox();
            this.mskbxaltura = new System.Windows.Forms.MaskedTextBox();
            this.txtimc = new System.Windows.Forms.TextBox();
            this.lblclass = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lblpeso
            // 
            this.lblpeso.AutoSize = true;
            this.lblpeso.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblpeso.Location = new System.Drawing.Point(109, 35);
            this.lblpeso.Name = "lblpeso";
            this.lblpeso.Size = new System.Drawing.Size(100, 24);
            this.lblpeso.TabIndex = 0;
            this.lblpeso.Text = "Peso Atual";
            // 
            // lblaltura
            // 
            this.lblaltura.AutoSize = true;
            this.lblaltura.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblaltura.Location = new System.Drawing.Point(109, 91);
            this.lblaltura.Name = "lblaltura";
            this.lblaltura.Size = new System.Drawing.Size(58, 24);
            this.lblaltura.TabIndex = 1;
            this.lblaltura.Text = "Altura";
            // 
            // lblimc
            // 
            this.lblimc.AutoSize = true;
            this.lblimc.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblimc.Location = new System.Drawing.Point(109, 171);
            this.lblimc.Name = "lblimc";
            this.lblimc.Size = new System.Drawing.Size(43, 24);
            this.lblimc.TabIndex = 2;
            this.lblimc.Text = "IMC";
            // 
            // btncalcular
            // 
            this.btncalcular.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.btncalcular.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btncalcular.Location = new System.Drawing.Point(390, 322);
            this.btncalcular.Name = "btncalcular";
            this.btncalcular.Size = new System.Drawing.Size(113, 40);
            this.btncalcular.TabIndex = 3;
            this.btncalcular.Text = "Calcular";
            this.btncalcular.UseVisualStyleBackColor = false;
            this.btncalcular.Click += new System.EventHandler(this.btncalcular_Click);
            // 
            // btnlimpar
            // 
            this.btnlimpar.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.btnlimpar.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnlimpar.Location = new System.Drawing.Point(183, 322);
            this.btnlimpar.Name = "btnlimpar";
            this.btnlimpar.Size = new System.Drawing.Size(113, 40);
            this.btnlimpar.TabIndex = 4;
            this.btnlimpar.Text = "Limpar";
            this.btnlimpar.UseVisualStyleBackColor = false;
            this.btnlimpar.Click += new System.EventHandler(this.btnlimpar_Click);
            // 
            // btnsair
            // 
            this.btnsair.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.btnsair.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnsair.Location = new System.Drawing.Point(542, 398);
            this.btnsair.Name = "btnsair";
            this.btnsair.Size = new System.Drawing.Size(113, 40);
            this.btnsair.TabIndex = 5;
            this.btnsair.Text = "Sair";
            this.btnsair.UseVisualStyleBackColor = false;
            this.btnsair.Click += new System.EventHandler(this.btnsair_Click);
            // 
            // mskbxpeso
            // 
            this.mskbxpeso.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.mskbxpeso.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mskbxpeso.Location = new System.Drawing.Point(251, 35);
            this.mskbxpeso.Mask = "00.00";
            this.mskbxpeso.Name = "mskbxpeso";
            this.mskbxpeso.Size = new System.Drawing.Size(199, 22);
            this.mskbxpeso.TabIndex = 6;
            this.mskbxpeso.ValidatingType = typeof(System.DateTime);
            this.mskbxpeso.MaskInputRejected += new System.Windows.Forms.MaskInputRejectedEventHandler(this.mskbxpeso_MaskInputRejected);
            this.mskbxpeso.Validating += new System.ComponentModel.CancelEventHandler(this.mskbxpeso_Validating);
            // 
            // mskbxaltura
            // 
            this.mskbxaltura.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.mskbxaltura.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mskbxaltura.Location = new System.Drawing.Point(251, 91);
            this.mskbxaltura.Mask = "0.00";
            this.mskbxaltura.Name = "mskbxaltura";
            this.mskbxaltura.Size = new System.Drawing.Size(199, 22);
            this.mskbxaltura.TabIndex = 7;
            this.mskbxaltura.MaskInputRejected += new System.Windows.Forms.MaskInputRejectedEventHandler(this.mskbxaltura_MaskInputRejected);
            this.mskbxaltura.Validating += new System.ComponentModel.CancelEventHandler(this.mskbxaltura_Validating);
            // 
            // txtimc
            // 
            this.txtimc.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtimc.Location = new System.Drawing.Point(251, 166);
            this.txtimc.Name = "txtimc";
            this.txtimc.ReadOnly = true;
            this.txtimc.Size = new System.Drawing.Size(199, 29);
            this.txtimc.TabIndex = 8;
            // 
            // lblclass
            // 
            this.lblclass.AutoSize = true;
            this.lblclass.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblclass.Location = new System.Drawing.Point(320, 216);
            this.lblclass.Name = "lblclass";
            this.lblclass.Size = new System.Drawing.Size(0, 24);
            this.lblclass.TabIndex = 9;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.ClientSize = new System.Drawing.Size(667, 450);
            this.Controls.Add(this.lblclass);
            this.Controls.Add(this.txtimc);
            this.Controls.Add(this.mskbxaltura);
            this.Controls.Add(this.mskbxpeso);
            this.Controls.Add(this.btnsair);
            this.Controls.Add(this.btnlimpar);
            this.Controls.Add(this.btncalcular);
            this.Controls.Add(this.lblimc);
            this.Controls.Add(this.lblaltura);
            this.Controls.Add(this.lblpeso);
            this.Name = "Form1";
            this.Text = "Cálculo IMC";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblpeso;
        private System.Windows.Forms.Label lblaltura;
        private System.Windows.Forms.Label lblimc;
        private System.Windows.Forms.Button btncalcular;
        private System.Windows.Forms.Button btnlimpar;
        private System.Windows.Forms.Button btnsair;
        private System.Windows.Forms.MaskedTextBox mskbxpeso;
        private System.Windows.Forms.MaskedTextBox mskbxaltura;
        private System.Windows.Forms.TextBox txtimc;
        private System.Windows.Forms.Label lblclass;
    }
}

