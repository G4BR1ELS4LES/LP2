﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PImc
{
    public partial class Form1 : Form
    {
        double peso, altura, imc;
        public Form1()
        {
            InitializeComponent();
        }

        private void btnsair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void mskbxpeso_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void mskbxpeso_Validating(object sender, CancelEventArgs e)
        {
            if((!double.TryParse(mskbxpeso.Text,out peso))||(peso<=0))
            {
                mskbxpeso.Clear();
                Focus();
            }

        }

        private void btncalcular_Click(object sender, EventArgs e)
        {
            imc = peso / (altura * altura);
            txtimc.Text = imc.ToString("n2");
            imc = Math.Round(imc, 1);
            if (imc < 18.5)
            {
                lblclass.Text = "MAGREZA";
                MessageBox.Show("Magreza");
            }
            else
            if (imc < 24.9)
            {
                lblclass.Text = "NORMAL";
                MessageBox.Show("Normal");
            }
            else
            if (imc < 29.9)
            {
                lblclass.Text = "SOBREPESO";
                MessageBox.Show("Sobrepeso");
            }
            else
            if (imc < 39.9)
            {
                lblclass.Text = "OBESIDADE";
                MessageBox.Show("Obesidade");
            }
            else
            {
                lblclass.Text = "OBESIDADE GRAVE";
                MessageBox.Show("Obesidade Grave");
            }
        }

        private void mskbxaltura_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void mskbxaltura_Validating(object sender, CancelEventArgs e)
        {
            if ((!double.TryParse(mskbxaltura.Text, out altura)) || (altura <= 0))
            {
                mskbxaltura.Clear();
                Focus();
            }
        }

        private void btnlimpar_Click(object sender, EventArgs e)
        {
            mskbxaltura.Clear();
            mskbxpeso.Clear();
            txtimc.Clear();
        }
    }
}
