﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pcalc
{
    public partial class Form1 : Form
    {
        double numero1, numero2, resultado; //globais

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnsoma_Click(object sender, EventArgs e)
        {
            resultado = numero1 + numero2;
            txtresultado.Text = resultado.ToString("");
            txtnumero1.Clear();
            txtnumero2.Clear();
        }

        private void btnsubtracao_Click(object sender, EventArgs e)
        {
            resultado = numero1 - numero2;
            txtresultado.Text = resultado.ToString("");
            txtnumero1.Clear();
            txtnumero2.Clear();
        }

        private void btndivisao_Click(object sender, EventArgs e)
        {
            if (numero2 == 0)
            {
                MessageBox.Show("Nao pode dividir por zero !!!","Erro",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtnumero2.Text = "";
                txtnumero2.Focus();
            }
            else
            {
                resultado = numero1 / numero2;
                txtresultado.Text = resultado.ToString("");
            }
            txtnumero1.Clear();
            txtnumero2.Clear();
        }

        private void btnmultiplicacao_Click(object sender, EventArgs e)
        {
            resultado = numero1 * numero2;
            txtresultado.Text = resultado.ToString("");
            txtnumero1.Clear();
            txtnumero2.Clear();
        }

        private void btnsair_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Voce deseja mesmo sair?",
                "Saída", MessageBoxButtons.YesNo,
                MessageBoxIcon.Question)==
                DialogResult.Yes)
            {
                Close();
            }
        }

        private void txtnumero2_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtnumero2_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtnumero2.Text, out numero2))
            {
                errorProvider2.SetError(txtnumero2, "Numero 2 invalido");
                //    MessageBox.Show("Numero invalido");
                txtnumero2.Focus();
            }
            else
                errorProvider2.SetError(txtnumero2, "");

            try
            {
                numero2 = Convert.ToDouble(txtnumero2.Text);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Numero invalido");
                txtnumero2.Focus();
            }
        }

        private void btnlimpar_Click(object sender, EventArgs e)
        {
            txtnumero1.Clear();
            txtnumero2.Clear();
            txtresultado.Clear();
            txtnumero1.Focus();
        }

        private void txtnumero1_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtnumero1.Text, out numero1))
            {
                errorProvider1.SetError(txtnumero1, "Numero 1 invalido");
                //    MessageBox.Show("Numero invalido");
                txtnumero1.Focus();
            }
            else
                errorProvider1.SetError(txtnumero1, "");
        }
    }
}
