﻿namespace PContato1
{
    partial class frmContato
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmContato));
            this.bnvContato = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.btnnovo = new System.Windows.Forms.ToolStripButton();
            this.btnsalvar = new System.Windows.Forms.ToolStripButton();
            this.btnalterar = new System.Windows.Forms.ToolStripButton();
            this.btnexcluir = new System.Windows.Forms.ToolStripButton();
            this.btncancelar = new System.Windows.Forms.ToolStripButton();
            this.btnsair = new System.Windows.Forms.ToolStripButton();
            this.dtpdtcontato = new System.Windows.Forms.TabControl();
            this.tbContato = new System.Windows.Forms.TabPage();
            this.dgvcontato = new System.Windows.Forms.DataGridView();
            this.tbdetalhes = new System.Windows.Forms.TabPage();
            this.txtendcontato = new System.Windows.Forms.TextBox();
            this.txtemailcontato = new System.Windows.Forms.TextBox();
            this.txtcelcontato = new System.Windows.Forms.TextBox();
            this.txtnomecontato = new System.Windows.Forms.TextBox();
            this.txtidcontato = new System.Windows.Forms.TextBox();
            this.cbxcidadecontato = new System.Windows.Forms.ComboBox();
            this.lblcadastro = new System.Windows.Forms.Label();
            this.lblemail = new System.Windows.Forms.Label();
            this.lblcelular = new System.Windows.Forms.Label();
            this.lblcidade = new System.Windows.Forms.Label();
            this.lblendereco = new System.Windows.Forms.Label();
            this.lblnome = new System.Windows.Forms.Label();
            this.lblid = new System.Windows.Forms.Label();
            this.dtpdtcadastrocontato = new System.Windows.Forms.DateTimePicker();
            ((System.ComponentModel.ISupportInitialize)(this.bnvContato)).BeginInit();
            this.bnvContato.SuspendLayout();
            this.dtpdtcontato.SuspendLayout();
            this.tbContato.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvcontato)).BeginInit();
            this.tbdetalhes.SuspendLayout();
            this.SuspendLayout();
            // 
            // bnvContato
            // 
            this.bnvContato.AddNewItem = null;
            this.bnvContato.CountItem = this.bindingNavigatorCountItem;
            this.bnvContato.DeleteItem = null;
            this.bnvContato.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2,
            this.btnnovo,
            this.btnsalvar,
            this.btnalterar,
            this.btnexcluir,
            this.btncancelar,
            this.btnsair});
            this.bnvContato.Location = new System.Drawing.Point(0, 0);
            this.bnvContato.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
            this.bnvContato.MoveLastItem = this.bindingNavigatorMoveLastItem;
            this.bnvContato.MoveNextItem = this.bindingNavigatorMoveNextItem;
            this.bnvContato.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
            this.bnvContato.Name = "bnvContato";
            this.bnvContato.PositionItem = this.bindingNavigatorPositionItem;
            this.bnvContato.Size = new System.Drawing.Size(885, 25);
            this.bnvContato.TabIndex = 0;
            this.bnvContato.Text = "bindingNavigator1";
            // 
            // bindingNavigatorCountItem
            // 
            this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
            this.bindingNavigatorCountItem.Size = new System.Drawing.Size(37, 22);
            this.bindingNavigatorCountItem.Text = "de {0}";
            this.bindingNavigatorCountItem.ToolTipText = "Número total de itens";
            // 
            // bindingNavigatorMoveFirstItem
            // 
            this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
            this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
            this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveFirstItem.Text = "Mover primeiro";
            // 
            // bindingNavigatorMovePreviousItem
            // 
            this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
            this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
            this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMovePreviousItem.Text = "Mover anterior";
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorPositionItem
            // 
            this.bindingNavigatorPositionItem.AccessibleName = "Posição";
            this.bindingNavigatorPositionItem.AutoSize = false;
            this.bindingNavigatorPositionItem.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
            this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(50, 23);
            this.bindingNavigatorPositionItem.Text = "0";
            this.bindingNavigatorPositionItem.ToolTipText = "Posição atual";
            // 
            // bindingNavigatorSeparator1
            // 
            this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator1";
            this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorMoveNextItem
            // 
            this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
            this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
            this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveNextItem.Text = "Mover próximo";
            // 
            // bindingNavigatorMoveLastItem
            // 
            this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
            this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
            this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveLastItem.Text = "Mover último";
            // 
            // bindingNavigatorSeparator2
            // 
            this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator2";
            this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // btnnovo
            // 
            this.btnnovo.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btnnovo.Image = ((System.Drawing.Image)(resources.GetObject("btnnovo.Image")));
            this.btnnovo.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnnovo.Name = "btnnovo";
            this.btnnovo.Size = new System.Drawing.Size(23, 22);
            this.btnnovo.Text = "Novo Registro";
            this.btnnovo.Click += new System.EventHandler(this.toolStripButton1_Click);
            // 
            // btnsalvar
            // 
            this.btnsalvar.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btnsalvar.Enabled = false;
            this.btnsalvar.Image = ((System.Drawing.Image)(resources.GetObject("btnsalvar.Image")));
            this.btnsalvar.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnsalvar.Name = "btnsalvar";
            this.btnsalvar.Size = new System.Drawing.Size(23, 22);
            this.btnsalvar.Text = "Salvar";
            this.btnsalvar.Click += new System.EventHandler(this.btnsalvar_Click);
            // 
            // btnalterar
            // 
            this.btnalterar.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btnalterar.Image = ((System.Drawing.Image)(resources.GetObject("btnalterar.Image")));
            this.btnalterar.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnalterar.Name = "btnalterar";
            this.btnalterar.Size = new System.Drawing.Size(23, 22);
            this.btnalterar.Text = "Alterar";
            this.btnalterar.Click += new System.EventHandler(this.toolStripButton3_Click);
            // 
            // btnexcluir
            // 
            this.btnexcluir.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btnexcluir.Image = ((System.Drawing.Image)(resources.GetObject("btnexcluir.Image")));
            this.btnexcluir.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnexcluir.Name = "btnexcluir";
            this.btnexcluir.Size = new System.Drawing.Size(23, 22);
            this.btnexcluir.Text = "Excluir";
            this.btnexcluir.Click += new System.EventHandler(this.btnexcluir_Click);
            // 
            // btncancelar
            // 
            this.btncancelar.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btncancelar.Enabled = false;
            this.btncancelar.Image = ((System.Drawing.Image)(resources.GetObject("btncancelar.Image")));
            this.btncancelar.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btncancelar.Name = "btncancelar";
            this.btncancelar.Size = new System.Drawing.Size(23, 22);
            this.btncancelar.Text = "Cancelar";
            this.btncancelar.Click += new System.EventHandler(this.toolStripButton5_Click);
            // 
            // btnsair
            // 
            this.btnsair.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btnsair.DoubleClickEnabled = true;
            this.btnsair.Image = ((System.Drawing.Image)(resources.GetObject("btnsair.Image")));
            this.btnsair.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnsair.Name = "btnsair";
            this.btnsair.Size = new System.Drawing.Size(23, 22);
            this.btnsair.Text = "Sair";
            this.btnsair.Click += new System.EventHandler(this.btnsair_Click);
            // 
            // dtpdtcontato
            // 
            this.dtpdtcontato.Controls.Add(this.tbContato);
            this.dtpdtcontato.Controls.Add(this.tbdetalhes);
            this.dtpdtcontato.Location = new System.Drawing.Point(29, 46);
            this.dtpdtcontato.Name = "dtpdtcontato";
            this.dtpdtcontato.SelectedIndex = 0;
            this.dtpdtcontato.Size = new System.Drawing.Size(802, 543);
            this.dtpdtcontato.TabIndex = 1;
            // 
            // tbContato
            // 
            this.tbContato.Controls.Add(this.dgvcontato);
            this.tbContato.Location = new System.Drawing.Point(4, 22);
            this.tbContato.Name = "tbContato";
            this.tbContato.Padding = new System.Windows.Forms.Padding(3);
            this.tbContato.Size = new System.Drawing.Size(794, 517);
            this.tbContato.TabIndex = 0;
            this.tbContato.Text = "Dados";
            this.tbContato.UseVisualStyleBackColor = true;
            // 
            // dgvcontato
            // 
            this.dgvcontato.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvcontato.Location = new System.Drawing.Point(20, 15);
            this.dgvcontato.Name = "dgvcontato";
            this.dgvcontato.Size = new System.Drawing.Size(756, 324);
            this.dgvcontato.TabIndex = 0;
            // 
            // tbdetalhes
            // 
            this.tbdetalhes.Controls.Add(this.txtendcontato);
            this.tbdetalhes.Controls.Add(this.txtemailcontato);
            this.tbdetalhes.Controls.Add(this.txtcelcontato);
            this.tbdetalhes.Controls.Add(this.txtnomecontato);
            this.tbdetalhes.Controls.Add(this.txtidcontato);
            this.tbdetalhes.Controls.Add(this.cbxcidadecontato);
            this.tbdetalhes.Controls.Add(this.lblcadastro);
            this.tbdetalhes.Controls.Add(this.lblemail);
            this.tbdetalhes.Controls.Add(this.lblcelular);
            this.tbdetalhes.Controls.Add(this.lblcidade);
            this.tbdetalhes.Controls.Add(this.lblendereco);
            this.tbdetalhes.Controls.Add(this.lblnome);
            this.tbdetalhes.Controls.Add(this.lblid);
            this.tbdetalhes.Controls.Add(this.dtpdtcadastrocontato);
            this.tbdetalhes.ImeMode = System.Windows.Forms.ImeMode.Off;
            this.tbdetalhes.Location = new System.Drawing.Point(4, 22);
            this.tbdetalhes.Name = "tbdetalhes";
            this.tbdetalhes.Padding = new System.Windows.Forms.Padding(3);
            this.tbdetalhes.Size = new System.Drawing.Size(794, 517);
            this.tbdetalhes.TabIndex = 1;
            this.tbdetalhes.Text = "Detalhes";
            this.tbdetalhes.UseVisualStyleBackColor = true;
            // 
            // txtendcontato
            // 
            this.txtendcontato.Enabled = false;
            this.txtendcontato.Location = new System.Drawing.Point(158, 122);
            this.txtendcontato.MaxLength = 100;
            this.txtendcontato.Name = "txtendcontato";
            this.txtendcontato.Size = new System.Drawing.Size(419, 20);
            this.txtendcontato.TabIndex = 14;
            // 
            // txtemailcontato
            // 
            this.txtemailcontato.Enabled = false;
            this.txtemailcontato.Location = new System.Drawing.Point(158, 249);
            this.txtemailcontato.MaxLength = 100;
            this.txtemailcontato.Name = "txtemailcontato";
            this.txtemailcontato.Size = new System.Drawing.Size(419, 20);
            this.txtemailcontato.TabIndex = 12;
            // 
            // txtcelcontato
            // 
            this.txtcelcontato.Enabled = false;
            this.txtcelcontato.Location = new System.Drawing.Point(158, 207);
            this.txtcelcontato.MaxLength = 15;
            this.txtcelcontato.Name = "txtcelcontato";
            this.txtcelcontato.Size = new System.Drawing.Size(419, 20);
            this.txtcelcontato.TabIndex = 11;
            // 
            // txtnomecontato
            // 
            this.txtnomecontato.Enabled = false;
            this.txtnomecontato.Location = new System.Drawing.Point(158, 82);
            this.txtnomecontato.MaxLength = 50;
            this.txtnomecontato.Name = "txtnomecontato";
            this.txtnomecontato.Size = new System.Drawing.Size(419, 20);
            this.txtnomecontato.TabIndex = 10;
            // 
            // txtidcontato
            // 
            this.txtidcontato.Enabled = false;
            this.txtidcontato.Location = new System.Drawing.Point(158, 41);
            this.txtidcontato.Name = "txtidcontato";
            this.txtidcontato.Size = new System.Drawing.Size(419, 20);
            this.txtidcontato.TabIndex = 9;
            // 
            // cbxcidadecontato
            // 
            this.cbxcidadecontato.Enabled = false;
            this.cbxcidadecontato.FormattingEnabled = true;
            this.cbxcidadecontato.Location = new System.Drawing.Point(158, 161);
            this.cbxcidadecontato.Name = "cbxcidadecontato";
            this.cbxcidadecontato.Size = new System.Drawing.Size(419, 21);
            this.cbxcidadecontato.TabIndex = 8;
            // 
            // lblcadastro
            // 
            this.lblcadastro.AutoSize = true;
            this.lblcadastro.Location = new System.Drawing.Point(39, 295);
            this.lblcadastro.Name = "lblcadastro";
            this.lblcadastro.Size = new System.Drawing.Size(75, 13);
            this.lblcadastro.TabIndex = 7;
            this.lblcadastro.Text = "Data Cadastro";
            // 
            // lblemail
            // 
            this.lblemail.AutoSize = true;
            this.lblemail.Location = new System.Drawing.Point(39, 252);
            this.lblemail.Name = "lblemail";
            this.lblemail.Size = new System.Drawing.Size(32, 13);
            this.lblemail.TabIndex = 6;
            this.lblemail.Text = "Email";
            // 
            // lblcelular
            // 
            this.lblcelular.AutoSize = true;
            this.lblcelular.Location = new System.Drawing.Point(39, 210);
            this.lblcelular.Name = "lblcelular";
            this.lblcelular.Size = new System.Drawing.Size(39, 13);
            this.lblcelular.TabIndex = 5;
            this.lblcelular.Text = "Celular";
            // 
            // lblcidade
            // 
            this.lblcidade.AutoSize = true;
            this.lblcidade.Location = new System.Drawing.Point(39, 164);
            this.lblcidade.Name = "lblcidade";
            this.lblcidade.Size = new System.Drawing.Size(40, 13);
            this.lblcidade.TabIndex = 4;
            this.lblcidade.Text = "Cidade";
            // 
            // lblendereco
            // 
            this.lblendereco.AutoSize = true;
            this.lblendereco.Location = new System.Drawing.Point(39, 125);
            this.lblendereco.Name = "lblendereco";
            this.lblendereco.Size = new System.Drawing.Size(53, 13);
            this.lblendereco.TabIndex = 3;
            this.lblendereco.Text = "Endereço";
            // 
            // lblnome
            // 
            this.lblnome.AutoSize = true;
            this.lblnome.Location = new System.Drawing.Point(39, 85);
            this.lblnome.Name = "lblnome";
            this.lblnome.Size = new System.Drawing.Size(35, 13);
            this.lblnome.TabIndex = 2;
            this.lblnome.Text = "Nome";
            // 
            // lblid
            // 
            this.lblid.AutoSize = true;
            this.lblid.Location = new System.Drawing.Point(39, 44);
            this.lblid.Name = "lblid";
            this.lblid.Size = new System.Drawing.Size(18, 13);
            this.lblid.TabIndex = 1;
            this.lblid.Text = "ID";
            // 
            // dtpdtcadastrocontato
            // 
            this.dtpdtcadastrocontato.CustomFormat = "dd/MM/yyyy";
            this.dtpdtcadastrocontato.Enabled = false;
            this.dtpdtcadastrocontato.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpdtcadastrocontato.Location = new System.Drawing.Point(158, 289);
            this.dtpdtcadastrocontato.Name = "dtpdtcadastrocontato";
            this.dtpdtcadastrocontato.Size = new System.Drawing.Size(419, 20);
            this.dtpdtcadastrocontato.TabIndex = 0;
            // 
            // frmContato
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(885, 641);
            this.Controls.Add(this.dtpdtcontato);
            this.Controls.Add(this.bnvContato);
            this.Name = "frmContato";
            this.Text = "Contato";
            this.Load += new System.EventHandler(this.frmContato_Load_1);
            ((System.ComponentModel.ISupportInitialize)(this.bnvContato)).EndInit();
            this.bnvContato.ResumeLayout(false);
            this.bnvContato.PerformLayout();
            this.dtpdtcontato.ResumeLayout(false);
            this.tbContato.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvcontato)).EndInit();
            this.tbdetalhes.ResumeLayout(false);
            this.tbdetalhes.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.BindingNavigator bnvContato;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private System.Windows.Forms.ToolStripButton btnnovo;
        private System.Windows.Forms.ToolStripButton btnsalvar;
        private System.Windows.Forms.ToolStripButton btnalterar;
        private System.Windows.Forms.ToolStripButton btnexcluir;
        private System.Windows.Forms.ToolStripButton btncancelar;
        private System.Windows.Forms.ToolStripButton btnsair;
        private System.Windows.Forms.TabControl dtpdtcontato;
        private System.Windows.Forms.TabPage tbContato;
        private System.Windows.Forms.TabPage tbdetalhes;
        private System.Windows.Forms.DataGridView dgvcontato;
        private System.Windows.Forms.TextBox txtendcontato;
        private System.Windows.Forms.TextBox txtemailcontato;
        private System.Windows.Forms.TextBox txtcelcontato;
        private System.Windows.Forms.TextBox txtnomecontato;
        private System.Windows.Forms.TextBox txtidcontato;
        private System.Windows.Forms.ComboBox cbxcidadecontato;
        private System.Windows.Forms.Label lblcadastro;
        private System.Windows.Forms.Label lblemail;
        private System.Windows.Forms.Label lblcelular;
        private System.Windows.Forms.Label lblcidade;
        private System.Windows.Forms.Label lblendereco;
        private System.Windows.Forms.Label lblnome;
        private System.Windows.Forms.Label lblid;
        private System.Windows.Forms.DateTimePicker dtpdtcadastrocontato;
    }
}

