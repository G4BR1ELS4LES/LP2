﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PContato1
{
    public partial class frmContato : Form
    {

        private BindingSource bncontato = new BindingSource();
        private bool binclusao = false;
        private DataSet dscontato = new DataSet();
        private DataSet dscidade = new DataSet();

        public frmContato()
        {
            InitializeComponent();
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            if (dtpdtcontato.SelectedIndex == 0)
            {
                dtpdtcontato.SelectTab(1);
            }
            bncontato.AddNew();
            txtnomecontato.Enabled = true;
            txtendcontato.Enabled = true;
            cbxcidadecontato.Enabled = true;
            // vai para o primeiro
            txtcelcontato.Enabled = true;
            txtemailcontato.Enabled = true;
            dtpdtcadastrocontato.Enabled = true;
            btnnovo.Enabled = false;
            btnalterar.Enabled = false;
            btnexcluir.Enabled = false;
            btnsalvar.Enabled = true;
            btncancelar.Enabled = true;
            binclusao = true;
        }

        private void toolStripButton3_Click(object sender, EventArgs e)
        {
            if (dtpdtcontato.SelectedIndex == 0)
            {
                dtpdtcontato.SelectTab(1);
            }
            txtnomecontato.Enabled = true;
            txtendcontato.Enabled = true;
            cbxcidadecontato.Enabled = true;
            txtcelcontato.Enabled = true;
            txtemailcontato.Enabled = true;
            dtpdtcadastrocontato.Enabled = true;
            btnnovo.Enabled = false;
            btnalterar.Enabled = false;
            btnexcluir.Enabled = false;
            btnsalvar.Enabled = true;
            btncancelar.Enabled = true;
            binclusao = false;
        }

        private void toolStripButton5_Click(object sender, EventArgs e)
        {
            bncontato.CancelEdit();
            txtnomecontato.Enabled = false;
            txtendcontato.Enabled = false;
            cbxcidadecontato.Enabled = false;
            txtcelcontato.Enabled = false;
            txtemailcontato.Enabled = false;
            dtpdtcadastrocontato.Enabled = false;
            btnnovo.Enabled = true;
            btnalterar.Enabled = true;
            btnexcluir.Enabled = true;
            btnsalvar.Enabled = false;
            btncancelar.Enabled = false;
            binclusao = false;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
           
        }

        private void btnsalvar_Click(object sender, EventArgs e)
        {
            if (txtnomecontato.Text == "")
            {
                MessageBox.Show("Nome inválido!");
            }
            else if (txtendcontato.Text == "")
            {
                MessageBox.Show("Endereço inválido!");
            }
            else if (cbxcidadecontato.SelectedIndex == -1)
            {
                MessageBox.Show("Cidade inválida!");
            }
            else if (txtcelcontato.Text == "")
            {
                MessageBox.Show("Celular inválido!");
            }
            else if (txtemailcontato.Text == "")
            {
                MessageBox.Show("E-mail inválido!");
            }
            else
            {
                Contato RegCon = new Contato();
                RegCon.Nomecontato = txtnomecontato.Text;
                RegCon.Endcontato = txtendcontato.Text;
                RegCon.Cidadeidcidade =
               Convert.ToInt32(cbxcidadecontato.SelectedValue.ToString());
                RegCon.Celcontato = txtcelcontato.Text;
                RegCon.Emailcontato = txtemailcontato.Text;
                RegCon.Dtcadastrocontato = dtpdtcadastrocontato.Value;
                if (binclusao)
                {
                    if (RegCon.Incluir() > 0)
                    {
                        MessageBox.Show("Contato adicionado com sucesso!");
                        txtnomecontato.Enabled = false;
                        txtendcontato.Enabled = false;
                        cbxcidadecontato.Enabled = false;
                        txtcelcontato.Enabled = false;
                        txtemailcontato.Enabled = false;
                        dtpdtcadastrocontato.Enabled = false;
                        btnnovo.Enabled = true;
                        btnalterar.Enabled = true;
                        btnexcluir.Enabled = true;
                        btnsalvar.Enabled = false;
                        btncancelar.Enabled = false;
                        binclusao = false;
                        // recarrega o grid
                        dscontato.Tables.Clear();
                        dscontato.Tables.Add(RegCon.Listar());
                        bncontato.DataSource = dscontato.Tables["Contato"];
                    }
                    else
                    {
                        MessageBox.Show("Erro ao gravar contato!");
                    }
                }
                else
                {
                    RegCon.Idcontato = Convert.ToInt32(txtidcontato.Text);
                    if (RegCon.Alterar() > 0)
                    {
                        MessageBox.Show("Contato alterado com sucesso!");
                        txtnomecontato.Enabled = false;
                        txtendcontato.Enabled = false;
                        cbxcidadecontato.Enabled = false;
                        txtcelcontato.Enabled = false;
                        txtemailcontato.Enabled = false;
                        dtpdtcadastrocontato.Enabled = false;
                        btnnovo.Enabled = true;
                        btnalterar.Enabled = true;
                        btnexcluir.Enabled = true;
                        btnsalvar.Enabled = false;
                        btncancelar.Enabled = false;
                        // recarrega o grid
                        dscontato.Tables.Clear();
                        dscontato.Tables.Add(RegCon.Listar());
                        bncontato.DataSource = dscontato.Tables["Contato"];
                    }
                    else
                    {
                        MessageBox.Show("Erro ao alterar contato!");
                    }
                }
            }
        }

        private void btnsair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void frmContato_Load_1(object sender, EventArgs e)
        {
            try
            {
                Contato Con = new Contato();
                dscontato.Tables.Add(Con.Listar());
                bncontato.DataSource = dscontato.Tables["Contato"];
                dgvcontato.DataSource = bncontato;
                bnvContato.BindingSource = bncontato;
                txtidcontato.DataBindings.Add("TEXT", bncontato, "id_contato");
                txtnomecontato.DataBindings.Add("TEXT", bncontato, "nome_contato");
                txtendcontato.DataBindings.Add("TEXT", bncontato, "end_contato");
                txtcelcontato.DataBindings.Add("TEXT", bncontato, "cel_contato");
                txtemailcontato.DataBindings.Add("TEXT", bncontato, "email_contato");
                dtpdtcadastrocontato.DataBindings.Add("TEXT", bncontato, "dtcadastro_contato");
                // carrega dados da cidade
                Cidade Cid = new Cidade();
                dscidade.Tables.Add(Cid.Listar());
                cbxcidadecontato.DataSource = dscidade.Tables["Cidade"];
                //CAMPO QUE SERÁ MOSTRADO PARA O USUÁRIO
                cbxcidadecontato.DisplayMember = "nome_cidade";
                //CAMPO QUE É A CHAVE DA TABELA CIDADE E QUE LIGA COM A TABELA DE ALUNO
                cbxcidadecontato.ValueMember = "id_cidade";
                //No momento de linkar os componentes com o Binding Source linkar também o combox da cidade 
                cbxcidadecontato.DataBindings.Add("SelectedValue", bncontato, "cidade_id_cidade");
                //AJUSTAR DROPDOWNSTYLE PARA DropDownList PARA NAO DEIXAR
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnexcluir_Click(object sender, EventArgs e)
        {
            if (dtpdtcontato.SelectedIndex == 0)
            {
                dtpdtcontato.SelectTab(1);
            }
            if (MessageBox.Show("Confirma exclusão?", "Yes or No", MessageBoxButtons.YesNo,
           MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
            {
                Contato RegCon = new Contato();
                RegCon.Idcontato = Convert.ToInt32(txtidcontato.Text);

                if (RegCon.Excluir() > 0)
                {
                    MessageBox.Show("Contato excluído com sucesso!");
                    // recarrega o grid
                    dscontato.Tables.Clear();
                    dscontato.Tables.Add(RegCon.Listar());
                    bncontato.DataSource = dscontato.Tables["Contato"];

                }
                else
                {
                    MessageBox.Show("Erro ao excluir contato!");
                }
            }
        }
    }
}
