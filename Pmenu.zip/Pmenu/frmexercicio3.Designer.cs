﻿namespace Pmenu
{
    partial class frmexercicio3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btninverter = new System.Windows.Forms.Button();
            this.btnremover = new System.Windows.Forms.Button();
            this.txtbxpalavra2 = new System.Windows.Forms.TextBox();
            this.txtbxpalavra1 = new System.Windows.Forms.TextBox();
            this.lblpalavra2 = new System.Windows.Forms.Label();
            this.lblpalavra1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btninverter
            // 
            this.btninverter.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btninverter.Location = new System.Drawing.Point(409, 295);
            this.btninverter.Name = "btninverter";
            this.btninverter.Size = new System.Drawing.Size(109, 76);
            this.btninverter.TabIndex = 14;
            this.btninverter.Text = "Inverter 1°";
            this.btninverter.UseVisualStyleBackColor = true;
            this.btninverter.Click += new System.EventHandler(this.btninverter_Click);
            // 
            // btnremover
            // 
            this.btnremover.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnremover.Location = new System.Drawing.Point(241, 295);
            this.btnremover.Name = "btnremover";
            this.btnremover.Size = new System.Drawing.Size(109, 76);
            this.btnremover.TabIndex = 13;
            this.btnremover.Text = "Remover ocorrências 1° no 2°";
            this.btnremover.UseVisualStyleBackColor = true;
            this.btnremover.Click += new System.EventHandler(this.btnremover_Click);
            // 
            // txtbxpalavra2
            // 
            this.txtbxpalavra2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbxpalavra2.Location = new System.Drawing.Point(337, 153);
            this.txtbxpalavra2.Name = "txtbxpalavra2";
            this.txtbxpalavra2.Size = new System.Drawing.Size(181, 26);
            this.txtbxpalavra2.TabIndex = 12;
            // 
            // txtbxpalavra1
            // 
            this.txtbxpalavra1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbxpalavra1.Location = new System.Drawing.Point(337, 76);
            this.txtbxpalavra1.Name = "txtbxpalavra1";
            this.txtbxpalavra1.Size = new System.Drawing.Size(181, 26);
            this.txtbxpalavra1.TabIndex = 11;
            // 
            // lblpalavra2
            // 
            this.lblpalavra2.AutoSize = true;
            this.lblpalavra2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblpalavra2.Location = new System.Drawing.Point(237, 156);
            this.lblpalavra2.Name = "lblpalavra2";
            this.lblpalavra2.Size = new System.Drawing.Size(70, 20);
            this.lblpalavra2.TabIndex = 10;
            this.lblpalavra2.Text = "Palavra2";
            // 
            // lblpalavra1
            // 
            this.lblpalavra1.AutoSize = true;
            this.lblpalavra1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblpalavra1.Location = new System.Drawing.Point(237, 76);
            this.lblpalavra1.Name = "lblpalavra1";
            this.lblpalavra1.Size = new System.Drawing.Size(70, 20);
            this.lblpalavra1.TabIndex = 9;
            this.lblpalavra1.Text = "Palavra1";
            // 
            // frmexercicio3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btninverter);
            this.Controls.Add(this.btnremover);
            this.Controls.Add(this.txtbxpalavra2);
            this.Controls.Add(this.txtbxpalavra1);
            this.Controls.Add(this.lblpalavra2);
            this.Controls.Add(this.lblpalavra1);
            this.Name = "frmexercicio3";
            this.Text = "frmexercicio3";
            this.Load += new System.EventHandler(this.frmexercicio3_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button btninverter;
        private System.Windows.Forms.Button btnremover;
        private System.Windows.Forms.TextBox txtbxpalavra2;
        private System.Windows.Forms.TextBox txtbxpalavra1;
        private System.Windows.Forms.Label lblpalavra2;
        private System.Windows.Forms.Label lblpalavra1;
    }
}