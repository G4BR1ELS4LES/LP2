﻿namespace Pmenu
{
    partial class frmexercicio2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblpalavra1 = new System.Windows.Forms.Label();
            this.lblpalavra2 = new System.Windows.Forms.Label();
            this.txtbxpalavra1 = new System.Windows.Forms.TextBox();
            this.txtbxpalavra2 = new System.Windows.Forms.TextBox();
            this.btnverificar = new System.Windows.Forms.Button();
            this.btninserir = new System.Windows.Forms.Button();
            this.btninserir2 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblpalavra1
            // 
            this.lblpalavra1.AutoSize = true;
            this.lblpalavra1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblpalavra1.Location = new System.Drawing.Point(111, 91);
            this.lblpalavra1.Name = "lblpalavra1";
            this.lblpalavra1.Size = new System.Drawing.Size(70, 20);
            this.lblpalavra1.TabIndex = 0;
            this.lblpalavra1.Text = "Palavra1";
            // 
            // lblpalavra2
            // 
            this.lblpalavra2.AutoSize = true;
            this.lblpalavra2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblpalavra2.Location = new System.Drawing.Point(111, 171);
            this.lblpalavra2.Name = "lblpalavra2";
            this.lblpalavra2.Size = new System.Drawing.Size(70, 20);
            this.lblpalavra2.TabIndex = 1;
            this.lblpalavra2.Text = "Palavra2";
            // 
            // txtbxpalavra1
            // 
            this.txtbxpalavra1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbxpalavra1.Location = new System.Drawing.Point(211, 91);
            this.txtbxpalavra1.Name = "txtbxpalavra1";
            this.txtbxpalavra1.Size = new System.Drawing.Size(254, 26);
            this.txtbxpalavra1.TabIndex = 3;
            // 
            // txtbxpalavra2
            // 
            this.txtbxpalavra2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbxpalavra2.Location = new System.Drawing.Point(211, 168);
            this.txtbxpalavra2.Name = "txtbxpalavra2";
            this.txtbxpalavra2.Size = new System.Drawing.Size(254, 26);
            this.txtbxpalavra2.TabIndex = 4;
            // 
            // btnverificar
            // 
            this.btnverificar.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnverificar.Location = new System.Drawing.Point(78, 291);
            this.btnverificar.Name = "btnverificar";
            this.btnverificar.Size = new System.Drawing.Size(103, 63);
            this.btnverificar.TabIndex = 6;
            this.btnverificar.Text = "Verificar Iguais";
            this.btnverificar.UseVisualStyleBackColor = true;
            // 
            // btninserir
            // 
            this.btninserir.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btninserir.Location = new System.Drawing.Point(223, 291);
            this.btninserir.Name = "btninserir";
            this.btninserir.Size = new System.Drawing.Size(103, 63);
            this.btninserir.TabIndex = 7;
            this.btninserir.Text = "Inserir 1° meio 2°";
            this.btninserir.UseVisualStyleBackColor = true;
            // 
            // btninserir2
            // 
            this.btninserir2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btninserir2.Location = new System.Drawing.Point(362, 291);
            this.btninserir2.Name = "btninserir2";
            this.btninserir2.Size = new System.Drawing.Size(103, 63);
            this.btninserir2.TabIndex = 8;
            this.btninserir2.Text = "Inserir 2 asteristicos";
            this.btninserir2.UseVisualStyleBackColor = true;
            // 
            // frmexercicio2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(611, 450);
            this.Controls.Add(this.btninserir2);
            this.Controls.Add(this.btninserir);
            this.Controls.Add(this.btnverificar);
            this.Controls.Add(this.txtbxpalavra2);
            this.Controls.Add(this.txtbxpalavra1);
            this.Controls.Add(this.lblpalavra2);
            this.Controls.Add(this.lblpalavra1);
            this.Name = "frmexercicio2";
            this.Text = "frmexercicio2";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblpalavra1;
        private System.Windows.Forms.Label lblpalavra2;
        private System.Windows.Forms.TextBox txtbxpalavra1;
        private System.Windows.Forms.TextBox txtbxpalavra2;
        private System.Windows.Forms.Button btnverificar;
        private System.Windows.Forms.Button btninserir;
        private System.Windows.Forms.Button btninserir2;
    }
}