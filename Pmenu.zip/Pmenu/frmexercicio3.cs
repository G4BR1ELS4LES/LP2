﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pmenu
{
    public partial class frmexercicio3 : Form
    {
        public frmexercicio3()
        {
            InitializeComponent();
        }

        private void btnremover_Click(object sender, EventArgs e)
        {
            txtbxpalavra2.Text = txtbxpalavra2.Text.Replace(txtbxpalavra1.Text, "");
        }

        private void frmexercicio3_Load(object sender, EventArgs e)
        {

        }

        private void btninverter_Click(object sender, EventArgs e)
        {
            char[] vetor = txtbxpalavra1.Text.ToCharArray();
            Array.Reverse(vetor);
            foreach (char c in vetor)
            {
                txtbxpalavra2.Text += c;
            }
            //string auxiliar = new string(vetor);
            //txtbxpalavra2.Text = auxiliar;
        }
    }
}
