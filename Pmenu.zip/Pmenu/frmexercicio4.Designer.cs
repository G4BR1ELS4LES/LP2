﻿namespace Pmenu
{
    partial class frmexercicio4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.rchtxtbxfrase = new System.Windows.Forms.RichTextBox();
            this.btnnum = new System.Windows.Forms.Button();
            this.btnbranco = new System.Windows.Forms.Button();
            this.btnalfa = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // rchtxtbxfrase
            // 
            this.rchtxtbxfrase.Location = new System.Drawing.Point(279, 79);
            this.rchtxtbxfrase.Name = "rchtxtbxfrase";
            this.rchtxtbxfrase.Size = new System.Drawing.Size(254, 123);
            this.rchtxtbxfrase.TabIndex = 0;
            this.rchtxtbxfrase.Text = "";
            // 
            // btnnum
            // 
            this.btnnum.Location = new System.Drawing.Point(172, 302);
            this.btnnum.Name = "btnnum";
            this.btnnum.Size = new System.Drawing.Size(111, 61);
            this.btnnum.TabIndex = 1;
            this.btnnum.Text = "Numérico";
            this.btnnum.UseVisualStyleBackColor = true;
            this.btnnum.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnbranco
            // 
            this.btnbranco.Location = new System.Drawing.Point(346, 302);
            this.btnbranco.Name = "btnbranco";
            this.btnbranco.Size = new System.Drawing.Size(111, 61);
            this.btnbranco.TabIndex = 2;
            this.btnbranco.Text = "Primeiro Caracter Branco";
            this.btnbranco.UseVisualStyleBackColor = true;
            // 
            // btnalfa
            // 
            this.btnalfa.Location = new System.Drawing.Point(511, 302);
            this.btnalfa.Name = "btnalfa";
            this.btnalfa.Size = new System.Drawing.Size(111, 61);
            this.btnalfa.TabIndex = 3;
            this.btnalfa.Text = "Alfabético";
            this.btnalfa.UseVisualStyleBackColor = true;
            // 
            // frmexercicio4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnalfa);
            this.Controls.Add(this.btnbranco);
            this.Controls.Add(this.btnnum);
            this.Controls.Add(this.rchtxtbxfrase);
            this.Name = "frmexercicio4";
            this.Text = "frmexercicio4";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.RichTextBox rchtxtbxfrase;
        private System.Windows.Forms.Button btnnum;
        private System.Windows.Forms.Button btnbranco;
        private System.Windows.Forms.Button btnalfa;
    }
}